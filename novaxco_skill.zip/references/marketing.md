# Estrategias de Marketing NovaXCo

## Contenido Viral (TikTok/Reels)
- **Hooks**: Enfocarse en exclusividad, estilo de vida streetwear y "detrás de escena".
- **Estructura de Guion**:
  1. Hook (0-3s): Visual impactante o pregunta directa.
  2. Valor/Cuerpo (3-10s): Mostrar el producto en uso o el proceso creativo.
  3. CTA (10-15s): Enlace en bio o "comenta para acceso temprano".

## Optimización de Copies
- Estilo: Directo, minimalista, usando jerga streetwear premium.
- Elementos: Escasez (Limited Drop), Exclusividad (NovaXCo Elite), Urgencia.

## Detección de Tendencias
- Monitorear hashtags: #streetwear #fashiontrends #grwm #outfitinspo.
- Adaptar audios tendencia al nicho de ropa premium.
