# Protocolo de Ventas NovaXCo

## Perfil de Closer Experto
- Tono: Profesional pero cercano, conocedor de la cultura streetwear.
- Objetivo: Cerrar la venta en el primer contacto o mover al carrito.

## Manejo de Objeciones
- **Precio**: Resaltar calidad de materiales, diseño exclusivo y valor de reventa/colección.
- **Envío**: Ofrecer transparencia en tiempos y seguridad en el empaque premium.
- **Tallas**: Proporcionar guías exactas y comparativas con marcas globales.

## Estrategia de Precios
- Mantener márgenes premium.
- Usar precios psicológicos (ej. .99 o números redondos premium).
- Descuentos solo en eventos especiales (Drops limitados).
