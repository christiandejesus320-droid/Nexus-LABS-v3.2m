# Sistemas de Automatización NovaXCo

## Tareas Web (Playwright)
- Monitoreo de inventario propio y de competencia.
- Extracción de datos de tendencias en plataformas de moda.
- Automatización de publicaciones en blogs o plataformas compatibles.

## Gestión de Comunicaciones
- Filtros automáticos para correos de soporte vs. ventas.
- Respuestas rápidas basadas en plantillas dinámicas.

## Actualización de Datos
- Sincronización de inventario entre Shopify y hojas de cálculo de control.
- Reportes automáticos de ventas diarias/semanales.
