# Quality Assurance Checklist

## 1. Responsive Intelligence
- [ ] **Mobile (375px)**: No horizontal overflow, touch targets ≥44px.
- [ ] **Tablet (768px)**: Grid adjustments, legible type.
- [ ] **Laptop (1024px)**: Layout stability.
- [ ] **Desktop (1440px)**: Content max-width, line length ≤75ch.
- [ ] **Ultra-wide**: Centered containers, no stretched images.
- [ ] **Orientation**: Landscape vs Portrait stability.

## 2. Accessibility (WCAG AA)
- [ ] **Contrast**: Body text ≥4.5:1, UI elements ≥3:1.
- [ ] **Keyboard**: Focus visible, logical tab order.
- [ ] **Semantics**: Proper use of <main>, <nav>, <header>, <footer>, <h1>-<h6>.
- [ ] **ARIA**: labels on icon-only buttons, dynamic state descriptions.
- [ ] **Touch**: No overlapping hit areas, minimum spacing.

## 3. Performance (Lighthouse Ready)
- [ ] **Images**: WebP/AVIF format, lazy loading, explicit width/height.
- [ ] **Fonts**: WOFF2, display: swap, preconnect.
- [ ] **CLS**: Reserve space for late-loading elements.
- [ ] **Hydration**: Minimal JS for static parts.
