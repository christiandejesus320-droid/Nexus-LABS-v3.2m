import os
import sys
import time
import sqlite3
import json
import hashlib
from pathlib import Path

# --- CONFIGURACIÓN ---
STATE_DIR = Path.home() / ".nexus"
DB_PATH = STATE_DIR / "nexus_state.sqlite"
STATE_DIR.mkdir(parents=True, exist_ok=True)

# --- BASE DE DATOS ---
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS goals (
            id TEXT PRIMARY KEY,
            session_id TEXT NOT NULL UNIQUE,
            objective TEXT NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('active', 'paused', 'complete')),
            token_budget INTEGER,
            tokens_used INTEGER DEFAULT 0,
            created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS phases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            goal_id TEXT,
            title TEXT NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('pending', 'in_progress', 'completed')),
            evidence TEXT,
            FOREIGN KEY(goal_id) REFERENCES goals(id)
        );
    """)
    return conn

# --- LÓGICA DE SESIÓN ---
def get_session_id():
    # Prioridad: Env var > Terminal ID > CWD
    session = os.environ.get("NEXUS_SESSION_ID") or os.environ.get("TERM_SESSION_ID")
    if session:
        return hashlib.sha256(session.encode()).hexdigest()[:12]
    cwd = str(Path.cwd())
    return hashlib.sha256(cwd.encode()).hexdigest()[:12]

# --- COMANDOS ---
def create_goal(objective, budget=None):
    sid = get_session_id()
    gid = hashlib.sha256(f"{objective}{time.time()}".encode()).hexdigest()[:8]
    conn = get_db()
    try:
        conn.execute(
            "INSERT INTO goals (id, session_id, objective, status, token_budget, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            (gid, sid, objective, 'active', budget, int(time.time()))
        )
        conn.commit()
        return f"🎯 Objetivo NEXUS establecido: {objective} (ID: {gid})"
    except sqlite3.IntegrityError:
        return "⚠️ Ya hay un objetivo activo en esta sesión. Usa /nexus status o /nexus clear."

def get_status():
    sid = get_session_id()
    conn = get_db()
    goal = conn.execute("SELECT * FROM goals WHERE session_id = ?", (sid,)).fetchone()
    if not goal:
        return "❌ No hay objetivos activos en esta sesión."
    
    phases = conn.execute("SELECT * FROM phases WHERE goal_id = ?", (goal['id'],)).fetchall()
    status_msg = f"🚀 [NEXUS] {goal['objective']}\n"
    status_msg += f"Status: {goal['status'].upper()} | Tokens: {goal['tokens_used']}/{goal['token_budget'] or '∞'}\n"
    
    if phases:
        status_msg += "\nFases:\n"
        for p in phases:
            icon = "✅" if p['status'] == 'completed' else "⏳" if p['status'] == 'in_progress' else "⭕"
            status_msg += f"{icon} {p['title']}\n"
    else:
        status_msg += "\nNo hay fases definidas aún. Usa /nexus loop para empezar."
    
    return status_msg

def stop_hook():
    """Lógica para el Stop Gate de Claude Code"""
    sid = get_session_id()
    conn = get_db()
    goal = conn.execute("SELECT * FROM goals WHERE session_id = ? AND status = 'active'", (sid,)).fetchone()
    if not goal:
        return "" # No bloquea si no hay goal activo
    
    # Verificar si hay trabajo pendiente
    pending_phase = conn.execute("SELECT * FROM phases WHERE goal_id = ? AND status != 'completed'", (goal['id'],)).fetchone()
    if pending_phase:
        return json.dumps({
            "decision": "block",
            "reason": f"⚠️ El objetivo NEXUS '{goal['objective']}' aún tiene trabajo pendiente. Completa la fase actual o usa /nexus pause."
        })
    return ""

if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "status"
    if cmd == "create":
        obj = " ".join(sys.argv[2:])
        print(create_goal(obj))
    elif cmd == "status":
        print(get_status())
    elif cmd == "stop-hook":
        print(stop_hook())
    elif cmd == "clear":
        sid = get_session_id()
        conn = get_db()
        conn.execute("DELETE FROM goals WHERE session_id = ?", (sid,))
        conn.commit()
        print("🧹 Sesión NEXUS limpiada.")
