# Arquitectura Nexus Super Skill

## Componentes

1.  **SQLite DB**: Almacena el estado global.
    - `goals`: Objetivo, presupuesto, tokens.
    - `phases`: Pasos específicos del loop.
2.  **Session Manager**: Resuelve el `session_id` usando variables de entorno de Claude Code.
3.  **Stop Gate Hook**: Script que se ejecuta cuando Claude intenta detenerse.
    - Si `decision == "block"`, Claude debe continuar trabajando.
    - Se basa en la existencia de fases pendientes en la DB.

## Flujo de Datos

```mermaid
graph TD
    A[Usuario: /goal] --> B[nexus_engine.py create]
    B --> C[(SQLite)]
    D[Claude: Stop] --> E[nexus_engine.py stop-hook]
    E --> F{¿Fases pendientes?}
    F -- Sí --> G[Block Stop]
    F -- No --> H[Allow Stop]
```
