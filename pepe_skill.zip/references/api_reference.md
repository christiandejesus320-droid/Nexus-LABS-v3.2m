# Sonner API Reference

## Installation
```bash
npm install sonner
# or
pnpm add sonner
# or
yarn add sonner
```

## Core Components

### Toaster
The main container for all toasts. Place it at the root of your application.

| Prop | Type | Description |
|------|------|-------------|
| position | Position | 'top-left' \| 'top-right' \| 'bottom-left' \| 'bottom-right' \| 'top-center' \| 'bottom-center' |
| theme | 'light' \| 'dark' \| 'system' | The theme of the toasts |
| richColors | boolean | Use rich colors for success, error, etc. |
| expand | boolean | Expand the stack of toasts by default |
| duration | number | Default duration in ms |
| visibleToasts | number | Amount of visible toasts |
| closeButton | boolean | Show a close button on all toasts |
| offset | string \| number | Offset from the edge |
| dir | 'rtl' \| 'ltr' \| 'auto' | Direction of the text |

## Toast Function
`toast(message, options)`

### Options (ExternalToast)
| Prop | Type | Description |
|------|------|-------------|
| description | ReactNode | Subtitle or description |
| duration | number | Custom duration for this toast |
| onDismiss | function | Callback when toast is dismissed |
| onAutoClose | function | Callback when toast closes automatically |
| action | Action | Primary action button |
| cancel | Action | Cancel button |
| id | string \| number | Custom ID |
| icon | ReactNode | Custom icon |
| invert | boolean | Invert colors |

### Toast Types
- `toast.success('Message')`
- `toast.error('Message')`
- `toast.info('Message')`
- `toast.warning('Message')`
- `toast.promise(promise, { loading, success, error })`
- `toast.loading('Message')`
- `toast.custom((t) => <div>...</div>)`

## Styling
Use `classNames` prop on `Toaster` for global styling or `className` on `toast` for individual toasts.

```tsx
<Toaster
  toastOptions={{
    classNames: {
      toast: 'my-toast-class',
      title: 'my-title-class',
      description: 'my-description-class',
      actionButton: 'my-action-button-class',
      cancelButton: 'my-cancel-button-class',
    },
  }}
/>
```
