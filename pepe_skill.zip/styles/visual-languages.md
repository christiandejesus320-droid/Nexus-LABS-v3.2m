# Visual Language Detection & Adaptation

## Supported Style Profiles

| Style | Core Characteristics | Key Tokens |
|-------|----------------------|------------|
| **Apple** | SF Pro, subtle gradients, high radius, San Francisco rhythm | `rounded-2xl`, `bg-white/80`, `backdrop-blur` |
| **Linear** | Inter, dark-mode focused, sharp borders, high contrast ink | `border-white/10`, `text-zinc-400`, `bg-[#0c0c0c]` |
| **Stripe** | Custom fonts, vibrant blurs, diagonal sections, complex shadows | `shadow-[0_1px_1px_rgba(0,0,0,0.1)]`, `bg-indigo-600` |
| **Raycast** | Mono fonts for secondary text, command-bar centric, ultra-fast feel | `font-mono`, `rounded-lg`, `bg-zinc-900` |
| **Vercel** | Geist font, monochrome, geometric, extreme precision | `rounded-none`, `border-black`, `bg-white` |
| **Notion** | Humanist, paper-like, clean, content-first | `font-serif`, `bg-[#ffffff]`, `text-[#37352f]` |
| **Arc** | Translucent, sidebar-centric, playful but professional | `opacity-90`, `saturate-150`, `rounded-xl` |
| **Supabase** | Green accents, developer-centric, clean grids | `text-emerald-500`, `bg-zinc-950` |
| **Minimal** | Swiss-inspired, no decoration, maximum whitespace | `p-12`, `tracking-tight`, `font-medium` |
| **Editorial** | Serif headings, large type, magazine layout | `font-serif`, `italic`, `leading-relaxed` |
| **Luxury** | Gold/Dark accents, high-end serif, thin strokes | `border-[0.5px]`, `text-amber-200`, `tracking-widest` |
| **Brutalist** | Raw, black borders, high saturation, no shadows | `border-2`, `shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]` |
| **Glass** | Translucency, frosted effects, vibrant backgrounds | `bg-white/10`, `backdrop-blur-xl`, `border-white/20` |

## Adaptation Logic
When a style is detected or requested:
1. **Typography**: Update font-family and tracking.
2. **Spacing**: Adjust padding/gap scale (Compact vs Relaxed).
3. **Radius**: Update `rounded-*` tokens.
4. **Shadows**: Switch between soft blurs, sharp lines, or no shadows.
5. **Motion**: Adjust duration and easing (Linear vs Spring).
