---
name: web-master
description: "Guía maestra para la creación de sitios web profesionales (Landing Pages, React Apps, Dashboards) con enfoque en alta conversión, performance (Lighthouse 90+) y SEO. Use para: definir estructuras de proyectos web, generar prompts de desarrollo de alta calidad y auditar la calidad del código."
---

# Master Web Creation Skill (NEXUS LABS Edition)

Esta skill integra el conocimiento de los mejores repositorios y expertos en desarrollo web para crear activos digitales de alto rendimiento. Está diseñada para maximizar la velocidad de ejecución y la calidad del resultado final en proyectos de NEXUS LABS.

## Capacidades Principales

| Capacidad | Descripción | Recurso de Referencia |
| :--- | :--- | :--- |
| **Definición de Proyecto** | Estructura inicial para asegurar que el proyecto resuelva un problema real. | `references/workflows.md` |
| **Generación de Prompts** | Prompts optimizados para Landing Pages, React Apps y Dashboards. | `references/prompts.md` |
| **Control de Calidad** | Checklists de performance (Lighthouse), SEO y Accesibilidad. | `references/quality_check.md` |
| **Flujo Agéntico** | Sistema paso a paso desde el setup inicial hasta el deployment. | `references/workflows.md` |

## Cómo usar esta Skill

1.  **Inicio**: Cuando el usuario pida crear un sitio web, lee `references/workflows.md` para definir la Fase 1.
2.  **Desarrollo**: Selecciona el prompt adecuado de `references/prompts.md` según el tipo de proyecto.
3.  **Auditoría**: Antes de entregar, verifica el cumplimiento con `references/quality_check.md`.

## Estándares Técnicos Requeridos

- **Stack**: Priorizar Tailwind CSS y Frameworks modernos (React/Next.js).
- **Performance**: Meta de Lighthouse > 90.
- **Mobile-First**: Diseño optimizado desde 320px.
- **SEO**: Semántica HTML5 correcta y Meta tags dinámicos.

---

*Nota: Esta skill está optimizada para ser ejecutada por Manus en nombre de NEXUS LABS, priorizando resultados prácticos y escalables.*
