# Catálogo de Prompts Maestros para Desarrollo Web

Este documento contiene los prompts de alto rendimiento extraídos de la "Master Web Creation Skill".

## 1. Landing Page de Alta Conversión
Usa este prompt para crear páginas de aterrizaje enfocadas en ventas.

```markdown
# Landing Page de Alta Conversión - [Tu Producto]

Quiero que crees una landing page profesional con estas especificaciones:

## Especificaciones Técnicas
- **Stack**: HTML5 + CSS3 (Tailwind) + JavaScript Vanilla
- **Performance**: Lighthouse 90+, <3s carga inicial
- **SEO**: Meta tags, schema.org, h1-h6 semánticos
- **Accesibilidad**: WCAG 2.1 AA, ARIA labels, keyboard nav
- **Mobile-First**: Responsive 320px - 1920px
- **Conversión**: CTA clara, color psychology, microcopy

## Estructura Requerida
1. **Header/Nav** - Logo, menú, CTA principal
2. **Hero** - Headline, subheading, imagen/video, CTA botón
3. **Pain Points** - 3-4 problemas que resuelves (con iconos)
4. **Features** - 6-8 características con beneficios
5. **Social Proof** - Testimonios, logos clientes, números
6. **FAQ** - Preguntas frecuentes con accordeón
7. **Pricing** - Tabla de precios o CTA
8. **Footer** - Links, newsletter signup, legal

## Requisitos de Diseño
- **Colores**: Primario [#667eea], Secundario [#764ba2], Blanco fondo
- **Tipografía**: Inter para body, Playfair Display para headings
- **Animaciones**: Smooth scroll, hover effects, fade-in al scroll
- **Microinteracciones**: Botones con hover, inputs con focus states

## Funcionalidad JavaScript
- Menú mobile hamburguesa
- Smooth scroll navigation
- Form validation (email, campos requeridos)
- Contador de estadísticas (con animación)
- Modal para email signup

## Integración
- Google Analytics (gtag)
- Favicon personalizado
- Open Graph meta tags
- Twitter Card

Genera TODO el código: HTML, CSS y JS en archivos separados.
```

## 2. React App Profesional
Para aplicaciones web más complejas con gestión de estado.

```markdown
# React App Profesional - [Nombre]

## Stack
```json
{
  "framework": "React 19",
  "styling": "Tailwind CSS",
  "state-management": "Zustand o Context API",
  "http-client": "axios o fetch",
  "build-tool": "Vite",
  "testing": "Vitest + React Testing Library",
  "linting": "ESLint + Prettier"
}
```

## Requisitos
- [ ] TypeScript strict mode
- [ ] Componentes funcionales + hooks
- [ ] Error boundaries
- [ ] Loading states
- [ ] Validación de formularios
- [ ] Tests unitarios (mínimo 70% cobertura)
- [ ] Responsive design
- [ ] Animaciones con Framer Motion
- [ ] Integración API (ejemplo con JSONPlaceholder)

Genera: Todos los archivos con código funcional, lista para `npm run dev`
```

## 3. Dashboard Ejecutivo
Visualización de datos y analíticas en tiempo real.

```markdown
# Dashboard Ejecutivo - Real-time Data Visualization

## Requisitos Técnicos
- **Frontend**: Next.js 14 + TypeScript
- **Styling**: Tailwind CSS + Shadcn/ui
- **Data Viz**: Recharts o Chart.js
- **Real-time**: WebSockets (Socket.io) o Server-Sent Events

## Componentes Requeridos
1. **Sidebar Navigation** - Activo, colapsable, con iconos
2. **Top KPI Cards** - Revenue, Users, Growth, Retention
3. **Charts** (Line, Bar, Pie, Heatmap)
4. **Data Tables** - Sorteable, paginación, búsqueda
5. **Date Range Picker**
6. **Export Buttons** - CSV, PDF, PNG
```

## 4. E-commerce Product Page
Focada en conversión máxima para tiendas online.

```markdown
# Página de Producto E-commerce - Conversión Máxima

## Especificaciones
- **Framework**: React o Next.js
- **Galería**: Zoom, thumbnails, 360 view simulado
- **Carrito**: Add to cart, cantidad, stock status
- **Reviews**: Formulario, listado con rating
- **SEO**: Rich snippets de producto
- **Checkout**: Form de pago (sin procesar real)
```
