# Flujos de Trabajo Agénticos para Desarrollo Web

Guía paso a paso para ejecutar proyectos web de alta calidad.

## 1. Definición del Proyecto (Fase 1)
Antes de empezar, define los cimientos:
- **¿Qué es?**: Definición en 1 línea.
- **¿Para quién?**: Público objetivo.
- **¿Qué problema resuelve?**: Valor principal.
- **¿Tecnología?**: Stack elegido (HTML/JS, React, Next.js).
- **¿Estilo?**: Mood visual.
- **¿Funcionalidad crítica?**: Lo que no puede faltar.

## 2. Estructura de Archivos (Fase 2)
Sigue siempre este estándar para organización profesional:

```
project-name/
├── .claude/              # Instrucciones contexto
├── src/
│   ├── components/       # Componentes
│   ├── pages/            # Páginas
│   ├── styles/           # CSS/Tailwind
│   └── utils/            # Lógica auxiliar
├── public/               # Assets estáticos
├── index.html
├── package.json
└── README.md
```

## 3. Iteración y Refinamiento (Fase 3)
Ciclo de mejora continua:
1. **Revisión de Código**: ¿Funciona localmente?
2. **Responsive Check**: ¿Se ve bien en móvil (320px)?
3. **Audit de Performance**: ¿Lighthouse > 90?
4. **Accesibilidad**: ¿Cumple WCAG 2.1?

## 4. Deployment (Fase 4)
- **Vercel**: Para Next.js y React (automático con Git).
- **Netlify**: Para sitios estáticos o React.
- **GitHub Pages**: Para demos rápidas y portafolios.
