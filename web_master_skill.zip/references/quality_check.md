# Checklist de Calidad y Auditoría Web

Usa este checklist antes de entregar cualquier proyecto.

## Auditoría de Rendimiento
- [ ] Puntuación Lighthouse >= 90
- [ ] Tiempo de interacción < 3s
- [ ] Cumulative Layout Shift (CLS) < 0.1
- [ ] Imágenes optimizadas (WebP, Lazy-loading)

## Auditoría de Accesibilidad
- [ ] Cumplimiento WCAG 2.1 AA
- [ ] Atributos ARIA completos
- [ ] Navegación por teclado funcional
- [ ] Contraste de color adecuado

## Auditoría de SEO
- [ ] Meta tags (title, description) completos
- [ ] Marcado Schema.org implementado
- [ ] Etiquetas Open Graph (OG) para redes sociales
- [ ] Estructura de encabezados (H1-H6) semántica

## Auditoría de Seguridad
- [ ] Sin secretos (API keys) hardcodeados
- [ ] CORS configurado correctamente
- [ ] Headers de seguridad básicos implementados
