---
name: llm-council
description: Create and manage an "LLM Council" to get high-quality responses by having multiple models review and rank each other. Use for complex queries, comparative analysis, and high-accuracy requirements.
---

# LLM Council

Este sistema permite agrupar múltiples modelos de lenguaje (GPT-4, Claude, Gemini, etc.) en un "consejo" para obtener respuestas de alta calidad mediante un proceso de tres etapas: opiniones individuales, revisión cruzada y respuesta final del "Presidente" (Chairman).

## Flujo de Trabajo

1. **Etapa 1: Opiniones Individuales**: La consulta se envía a todos los LLM configurados.
2. **Etapa 2: Revisión**: Cada LLM revisa y califica las respuestas de los demás (de forma anónima).
3. **Etapa 3: Respuesta Final**: Un modelo "Presidente" compila todo en una respuesta final coherente.

## Cómo usar

Para ejecutar la aplicación localmente:

```bash
cd /home/ubuntu/llm-council
./start.sh
```

### Configuración

- **API Keys**: Configura `OPENROUTER_API_KEY` en un archivo `.env` en la raíz del proyecto.
- **Modelos**: Edita `backend/config.py` para cambiar los modelos del consejo o el presidente.

## Recursos del Proyecto

- **Backend**: FastAPI (Python 3.10+)
- **Frontend**: React + Vite
- **Ubicación**: `/home/ubuntu/llm-council`

## Notas de Uso

- El proyecto utiliza **OpenRouter** para acceder a múltiples modelos.
- Las conversaciones se guardan en `data/conversations/` en formato JSON.
